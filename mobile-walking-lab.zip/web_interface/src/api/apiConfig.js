// export const BASE_URL = "http://192.168.1.214:5001/api";
export const BASE_URL = "https://mobile-walking-lab-server-b0fhd9bxfmcafgae.westeurope-01.azurewebsites.net/api";

